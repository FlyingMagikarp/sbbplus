<?php

require 'Model/Model.php';

class Controller{

    public $model;

    public function __construct(){
        $this->model = new Model();
    }

    // Worker
    public function getWorker(){
        $dataDB = $this->model->getWorker();
        $dataArray = array();
        while($row = $dataDB->fetch_assoc()){
            //$firstname,$lastname,$position,$id
            $worker = new Model_Worker($row['Firstname'],$row['Lastname'],$row['Position'],$row['ID']);
            array_push($dataArray,$worker);
        }
        return $dataArray;
    }

    public function getWorkerPositions(){
        $dataDB = $this->model->getWorkerPositions();
        $dataArray = array();
        while($row = $dataDB->fetch_assoc()){
            array_push($dataArray,$row);
        }
        return $dataArray;
    }

    public function addWorker($worker){
        $this->model->addWorker($worker);
    }


    // Trains Material
    public function addMaterial($train){
        $this->model->addMaterial($train);
    }

    public function updateMaterial($material){
        $this->model->updateMaterial($material);
    }

    public function getMaterials(){
        $dataDB = $this->model->getMaterials();
        $dataArray = array();
        while($row = $dataDB->fetch_assoc()){
            // $type,$startDate,$lastCheck,$nextCheck,$available,$class=1,$space=0,$id=0
            $train = new Model_Material($row['Type'],$row['StartDate'],$row['LastCheck'],$row['NextCheck'],$row['Available'],$row['Class'],$row['Space'],$row['ID']);
            array_push($dataArray,$train);
        }
        return $dataArray;
    }

    public function getMaterialClasses(){
        $dataDB = $this->model->getMaterialClasses();
        $dataArray = array();
        while($row = $dataDB->fetch_assoc()){
            array_push($dataArray,$row);
        }
        return $dataArray;
    }

    public function getMaterialTypes(){
        $dataDB = $this->model->getMaterialTypes();
        $dataArray = array();
        while($row = $dataDB->fetch_assoc()){
            array_push($dataArray,$row);
        }
        return $dataArray;
    }

    public function getMaterial($materialID){
        $dataDB = $this->model->getMaterial($materialID);
        $material = false;
        while($row = $dataDB->fetch_assoc()){
            //$type,$startDate,$lastCheck,$nextCheck,$available,$class=1,$space=0,$id=0
            $material = new Model_Material($row["Type"],$row["StartDate"],$row["LastCheck"],$row["NextCheck"],$row["Available"],$row["Class"],$row["Space"],$row["ID"]);
        }
        return $material;
    }


    //Routes
    public function getRoutes(){
        $dataDB = $this->model->getRoutes();
        $dataArray = array();
        while($row = $dataDB->fetch_assoc()){
            $route = new Model_Route($row["ID"],$row["Name"]);
            array_push($dataArray,$route);
        }
        return $dataArray;
    }

    public function getStationsForRoute($route){
        $dataDB = $this->model->getStations($route);
        $dataArray = array();
        while($row = $dataDB->fetch_assoc()){
            $station = new Model_Station($row["ID"],$row["Name"],$row["Previous"],$row["Next"],$row["TravelTime"],$row["Wait"],$row["Storage"]);
            array_push($dataArray, $station);
        }
        return $dataArray;
    }

    public function getStationById($id,$route){
        $dataDB = $this->model->getStationById($id,$route);
        $station = "empty";
        while($row = $dataDB->fetch_assoc()){
            $station = new Model_Station($row["ID"],$row["Name"],$row["Previous"],$row["Next"],$row["TravelTime"],$row["Wait"],$row["Storage"]);
        }
        return $station;
    }


    // Timetable
    public function generateTimetable($stations,$route){
        // 1440min in a day
        // from 05:30 to 00:00  1110mins
        // 05:30 -> 330
        // 00:00 -> 0
        // 06:30 to 08:30 every 15
        // 06:30 -> 390
        // 08:30 -> 510
        // 11:30 to 13:30 every 15
        // 11:30 -> 690
        // 13:30 -> 810
        // 16:00 to 19:00 every 15
        // 16:00 -> 960
        // 19:00 -> 1140
        $this->generateRouteArray($route);
    }


    public function generateRouteArray($routeName){
        $route = array();
        $travelTime = $this->model->getTravelTimeTotal($routeName)->fetch_assoc();
        $waitTime = $this->model->getWaitTimeTotal($routeName)->fetch_assoc();
        $totalTime = intval($travelTime["T"])+intval($waitTime["W"]);


    }


    // Other
    public function getPositionNameById($id){
        $dataDB = $this->model->getPositionNameById($id);
        $data = 0;
        while($row = $dataDB->fetch_assoc()){
            $data = $row['Position'];
        }
        return $data;
    }
}