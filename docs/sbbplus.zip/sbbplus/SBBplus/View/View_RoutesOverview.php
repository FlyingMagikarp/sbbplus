<?php

require '../Controller.php';
include '../res/head.php';
include 'Nav.php';

class View_RoutesOverview
{
    public $controller;

    public function __construct(){
        $this->controller = new Controller();
    }

    // get all available Routes
    public function getRoutes(){
        $routesData = $this->controller->getRoutes();
        return $routesData;
    }


}
$self = new View_RoutesOverview();
//Load Data
$routesData = $self->getRoutes()



?>
<html>
<head>

</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Linien</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
        </tr>
        <?php for($i = 0;$i<sizeof($routesData);$i++): ?>
        <?php $j = $i+1; $routeLink = "View_Route".$j.".php"; ?>
        <tr>

            <td><?php echo $routesData[$i]->id ?></td>
            <td><?php echo $routesData[$i]->name ?></td>
            <td><a href=<?php echo $routeLink ?>><button>View</button></a></td>
        </tr>
        <?php endfor; ?>
    </table>
</div>
</body>
</html>
