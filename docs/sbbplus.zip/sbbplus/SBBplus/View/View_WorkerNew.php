<?php

require '../Controller.php';
include '../res/head.php';
include 'Nav.php';
//require '../Model/Model_Worker.php';

class View_WorkerNew
{
    public $controller;

    public function __construct(){
        $this->controller = new Controller();
    }

    //returns a list with all possible positions
    public function getPositions(){
        return $this->controller->getWorkerPositions();
    }

    //adds a worker
    public function addWorker($worker){
        $this->controller->addWorker($worker);
    }

}
$self = new View_WorkerNew();


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $firstname = check_input($_POST["firstname"]);
    $lastname = check_input($_POST["lastname"]);
    $position = check_input($_POST["positions"]);

    $worker = new Model_Worker($firstname,$lastname,$position);
    $self->addWorker($worker);
    //redirect back to overview
    header("Location: View_Worker.php");
    exit();

}



//escape sepcial characters and html tags
function check_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Neuer Arbeiter Erfassen</h1>
    <form name="newWorker" action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?> method="post">
        <table>
            <tr>
                <td><label>Vorname: </label></td>
                <td><input id="firstname" name="firstname" type="text" required /></td>
            </tr>
            <tr>
                <td><label>Nachname: </label></td>
                <td><input id="lastname" name="lastname" type="text" required /></td>
            </tr>
            <tr>
                <td><label>Position: </label></td>
                <td>
                    <?php
                    $positionsData = $self->getPositions();
                    for($i = 0; $i < sizeof($positionsData); $i++): ?>
                        <li class="workerNewLists"><input type="radio" name="positions" value="<?php echo $i+1 ?>" required /><?php echo ' '.$positionsData[$i]['Position'] ?></li>
                    <?php endfor; ?>
                </td>
            </tr>
        </table>
        <input type="submit">
        <input type="reset">
    </form>
</div>
</body>
</html>
