<?php


require '../Controller.php';
include '../res/head.php';
include 'Nav.php';

class View_Route1
{
    public $controller;

    public function __construct(){
        $this->controller = new Controller();
    }

    public function getStations(){
        return $this->controller->getStationsForRoute("Route1");
    }

    public function getStationById($id){
        return $this->controller->getStationById($id,"Route1");
    }



}
$self = new View_Route1();
$stations = $self->getStations();

?>
<html>
<head>

</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Linie 1</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>&nbsp;</th>
            <th>Vorherige Station</th>
            <th>ID</th>
            <th>&nbsp;</th>
            <th>Nächste Station</th>
            <th>ID</th>
            <th>&nbsp;</th>
            <th>Wartezeit</th>
            <th>Lager</th>
        </tr>
    <?php for($i = 0;$i<sizeof($stations);$i++): ?>
    <?php
        $previous = "";
        $next = "";
        $storageBox = "";
        $station = $stations[$i];
        $preStation = $self->getStationById($station->previous);
        $nextStation = $self->getStationById($station->next);

        if($preStation!="empty") {
            $previous = $preStation->name;
        }
        if($nextStation!="empty"){
            $next = $nextStation->name;
        }

        if($station->storage == 1){
            $storageBox = "<b>1</b>";
        }else{
            $storageBox = "<b>0</b>";
        }


        ?>
        <tr>
            <td><?php echo $station->id; ?></td>
            <td><?php echo $station->name; ?></td>
            <td>&nbsp;</td>
            <td><?php echo $previous; ?></td>
            <td><?php echo $station->previous; ?></td>
            <td>&nbsp;</td>
            <td><?php echo $next; ?></td>
            <td><?php echo $station->next; ?></td>
            <td>&nbsp;</td>
            <td><?php echo $station->wait." min"; ?></td>
            <td><?php echo $station->storage; ?></td>
        </tr>
    <?php endfor; ?>
    </table>
</div>
</body>
</html>
