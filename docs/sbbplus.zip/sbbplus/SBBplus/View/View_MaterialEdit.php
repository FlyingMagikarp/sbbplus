<?php

require '../Controller.php';
include '../res/head.php';
include 'Nav.php';

class View_MaterialEdit
{
    public $controller;
    public $material;
    public $materialID;

    public function __construct($materialID = 0){
        $this->controller = new Controller();
        $this->materialID = $materialID;
        if($materialID > 0){
            $this->createTrainObj();
        }
    }

    public function createTrainObj(){
        $this->material = $this->controller->getMaterial($this->materialID);
    }

    //returns a list of all types
    public function getMaterialTypes(){
        return $this->controller->getMaterialTypes();
    }

    //returns list of all classes
    public function getClasses(){
        return $this->controller->getMaterialClasses();
    }

    public function updateMaterial($material){
        return $this->controller->updateMaterial($material);
    }



}
if($_POST['trainID']) {
    $materialID = $_POST['trainID'];
    $self = new View_MaterialEdit($materialID);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && !$_POST['trainID']) {
    //update material
    $id = $_POST['materialID'];
    $type = $_POST['types'];
    $startDate = $_POST['startDate'];
    $lastCheck = $_POST['lastCheck'];
    $nextCheck = $_POST['nextCheck'];
    $available = $_POST['available'];
    if($type = 1) {
        $class = $_POST['classes'];
        $space = $_POST['space'];
    } else {
        $class = 0;
        $space = 0;
    }

    $self = new View_MaterialEdit($id);

    $material = new Model_Material($type,$startDate,$lastCheck,$nextCheck,$available,$class,$space,$id);
    //var_dump($material); die();
    $self->updateMaterial($material);
    //redirect back to overview
    header("Location: View_Material.php");
    exit();

}

?>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Material Bearbeiten</h1>
    <form name="editMaterial" action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?> method="post">
        <table>
            <tr>
                <td><label>ID: </label></td>
                <td><input name="materialID" type="text" readonly value="<?php echo $self->material->id; ?>"></td>
            </tr>
            <tr>
                <td><label>Types: </label></td>
                <td>
                    <?php
                    $typeData = $self->getMaterialTypes();
                    for($i = 0;$i<sizeof($typeData);$i++): ?>
                        <?php if($i+1 == $self->material->type): ?>
                            <li class="trainNewLists"><input type="radio" name="types" id="<?php echo "typeRadio".$i; ?>" value="<?php echo $i+1 ?>" required checked /><?php echo ' '.$typeData[$i]['Type'] ?></li>
                        <?php else: ?>
                            <li class="trainNewLists"><input type="radio" name="types" id="<?php echo "typeRadio".$i; ?>" value="<?php echo $i+1 ?>" required /><?php echo ' '.$typeData[$i]['Type'] ?></li>
                        <?php endif; ?>
                    <?php endfor; ?>
                </td>
            </tr>
            <tr>
                <td><label>Inbetriebnahme: </label></td>
                <td><input name="startDate" type="date" value="<?php echo $self->material->startDate; ?>"></td>
            </tr>
            <tr>
                <td><label>Letzte Revision: </label></td>
                <td><input name="lastCheck" type="date" value="<?php echo $self->material->lastCheck ?>"></td>
            </tr>
            <tr>
                <td><label>Nächste Revision: </label></td>
                <td><input name="nextCheck" type="date" value="<?php echo $self->material->nextCheck ?>"></td>
            </tr>
            <tr>
                <td><label>Verfügbar: </label></td>
                <td>
                    <li class="trainNewLists"><input type="radio" name="available" value="false" <?php if($self->material->available === "false"){echo "checked";}; ?>>Nein</li>
                    <li class="trainNewLists"><input type="radio" name="available" value="true" <?php if($self->material->available === "true"){echo "checked";}; ?>>Ja</li>
                </td>
            </tr>
        </table>
        <div id="wagon" <?php if($self->material->type != 1){echo "hidden";}; ?>>
            <table>
                <tr>
                    <td><label>Klasse: </label></td>
                    <td>
                        <?php
                        $classData = $self->getClasses();
                        for($i = 0;$i < sizeof($classData);$i++): ?>
                            <li class="trainNewLists"><input type="radio" name="classes" id="<?php echo "classRadio".$i ?>" value="<?php echo $i+1 ?>" <?php if($i+1 == $self->material->class){echo "checked";}; ?>/><?php echo ' '.$classData[$i]['Class'] ?></li>
                        <?php endfor; ?>
                    </td>
                </tr>
                <tr>
                    <td><label>Anzahl Plätze: </label></td>
                    <td><input type="text" name="space" value="<?php echo $self->material->space ?>" /></td>
                </tr>
            </table>
        </div>
        <input type="submit">
        <input type="reset">
    </form>
</div>
<script src="../js/jquery.min.js"></script>

<script>
    $('input[type=radio][name=types]').change(function() {
        if (this.value == '1') {
            $('#wagon').show();
            //$('#train').hide();
        }
        else if (this.value == '2') {
            $('#wagon').hide();
            //$('#train').show();
        }
    });
</script>
</body>
</html>