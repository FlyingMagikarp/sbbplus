<?php

require '../Controller.php';
include '../res/head.php';
include 'Nav.php';

class View_Timetable
{

}

?>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Zeitplan Generieren</h1>

    <a href="View_TimetableRoute1.php"><button>Route1</button></a>
</div>
</body>
</html>
