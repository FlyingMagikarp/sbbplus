<?php
function getNavbar(){
    return ('
    <h1>Ländliche Ostbahnen AG</h1>
    <a href="/web/SBBplus"><button class="btn">Home</button></a>
    <a href="/web/SBBplus/View/View_Worker.php"><button class="btn">Personal</button></a>
    <a href="/web/SBBplus/View/View_Material.php"><button class="btn">Rollmaterial</button></a>
    <button class="btn">Stationen</button>
    <a href="/web/SBBplus/View/View_RoutesOverview.php"><button class="btn">Linien</button></a>
    ');
}
?>