<?php

require '../Controller.php';
include '../res/head.php';
include 'Nav.php';

class View_TimetableRoute1
{
    public $controller;

    public function __construct(){
        $this->controller = new Controller();
    }

    public function getStations(){
        return $this->controller->getStationsForRoute("Route1");
    }

    public function getStationById($id){
        return $this->controller->getStationById($id,"Route1");
    }

}
$self = new View_TimetableRoute1();
$stations = $self->getStations();

?>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Zeitplan Route1</h1>
    <div class="timetable">
        <?php $self->controller->generateTimetable($stations,"Route1") ?>





    </div>
</div>
</body>
</html>
