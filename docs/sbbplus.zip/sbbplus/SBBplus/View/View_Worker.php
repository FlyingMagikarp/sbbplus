<?php

require '../Controller.php';
include '../res/head.php';
include 'Nav.php';

class View_Worker
{
    public $controller;

    public function __construct(){
        $this->controller = new Controller();
    }

    // get all worker data
    public function getWorker(){
        $workerData = $this->controller->getWorker();
        return $workerData;
    }

    //returns a list with all possible positions
    public function getPositions(){
        return $this->controller->getWorkerPositions();
    }


}
$self = new View_Worker();
//Load Data
$workerData = $self->getWorker();



?>
<html>
<head>

</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Personalverwaltung</h1>

    <a href="View_WorkerNew.php"><button>Neuer Arbeiter erfassen</button></a>
    <table>
        <tr>
            <th>Personalnummer</th>
            <th>Nachname</th>
            <th>Vornamename</th>
            <th>Position</th>
        </tr>
        <?php for($i = 0;$i<sizeof($workerData);$i++): ?>
        <tr>
            <td><?php echo $workerData[$i]->id ?></td>
            <td><?php echo $workerData[$i]->lastname ?></td>
            <td><?php echo $workerData[$i]->firstname ?></td>
            <td><?php
                $posArray = $self->getPositions();
                echo $posArray[$workerData[$i]->position - 1]['Position'];
                ?></td>

            <td><a href="#"><img class="icon" src="../res/icons/edit.png"></a></td>
            <td><a href="#"><img class="icon" src="../res/icons/delete.png"></a></td>
        </tr>
        <?php endfor; ?>
    </table>
</div>
</body>
</html>
