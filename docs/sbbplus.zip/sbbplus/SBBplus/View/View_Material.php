<?php

require '../Controller.php';
include '../res/head.php';
include 'Nav.php';

class View_Material
{
    public $controller;

    public function __construct(){
        $this->controller = new Controller();
    }

    //get all train material
    public function getMaterials(){
        $trainData = $this->controller->getMaterials();
        return $trainData;
    }

    public function getClasses(){
        $classData = $this->controller->getMaterialClasses();
        return $classData;
    }

}
$self = new View_Material();
// Load Data
$trainData = $self->getMaterials();




?>
<html>
<head>

</head>
<body>
<div class="wrapper">
    <div class="navbar">
        <?php echo getNavbar(); ?>
    </div>
    <h1>Materialverwaltung</h1>

    <a href="View_MaterialNew.php"><button>Neues Material erfassen</button></a>
    <table>
        <tr>
            <th>ID</th>
            <th>Typ</th>
            <th>Inbetriebnahme</th>
            <th>Letzte Revision</th>
            <th>Nächste Revision</th>
            <th>Verfügbar</th>
            <th>Klasse</th>
            <th>Anzahl Plätze</th>
            <th>Edit</th>
        </tr>
        <?php for($i = 0;$i<sizeof($trainData);$i++): ?>
        <form name="EditTrain" action="View_MaterialEdit.php" method="post">
            <tr>
                <td><?php echo $trainData[$i]->id ?><input name="trainID" value="<?php echo $trainData[$i]->id ?>" hidden></td>
                <td><?php echo $trainData[$i]->type ?></td>
                <td><?php echo $trainData[$i]->startDate ?></td>
                <td><?php echo $trainData[$i]->lastCheck ?></td>
                <td><?php echo $trainData[$i]->nextCheck ?></td>
                <td><?php echo $trainData[$i]->available ?></td>
                <td><?php if($trainData[$i]->type == 1):
                    $classData = $self->getClasses();
                    echo $classData[$trainData[$i]->class - 1]['Class'] ?></td>
                <td><?php echo $trainData[$i]->space ?></td>
                <?php else: ?>
                <td>&nbsp;</td>
                <?php endif; ?>
                <td><button type="submit" name="edit"><img src="../res/icons/edit.png" class="submitIcn" /></button></td>
            </tr>
        </form>
        <?php endfor; ?>
    </table>
</div>
</body>
</html>