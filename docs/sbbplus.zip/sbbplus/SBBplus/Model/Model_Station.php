<?php

class Model_Station
{
    public $id;
    public $name;
    public $previous;
    public $next;
    public $travelTime;
    public $wait;
    public $storage;

    public function __construct($id,$name,$previous,$next,$wait,$travelTime,$storage){
        $this->id = $id;
        $this->name = $name;
        $this->previous = $previous;
        $this->next = $next;
        $this->travelTime = $travelTime;
        $this->wait = $wait;
        $this->storage = $storage;
    }

}