<?php

class Model_Material
{
    public $id;
    public $type;
    public $startDate;
    public $lastCheck;
    public $nextCheck;
    public $class;
    public $space;
    public $available;

    public function __construct($type,$startDate,$lastCheck,$nextCheck,$available,$class=1,$space=0,$id=0){
        $this->id = $id;
        $this->type = $type;
        $this->startDate = $startDate;
        $this->lastCheck = $lastCheck;
        $this->nextCheck = $nextCheck;
        $this->available = $available;
        $this->class = $class;
        $this->space = $space;

    }

}