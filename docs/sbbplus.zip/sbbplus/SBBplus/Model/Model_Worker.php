<?php

class Model_Worker
{
    public $id;
    public $firstname;
    public $lastname;
    public $position;

    public function __construct($firstname,$lastname,$position,$id=0){
        $this->id = $id;
        $this->firstname = $firstname;
        $this->lastname = $lastname;
        $this->position = $position;
    }


}