<?php

require 'Model_Worker.php';
require 'Model_Material.php';
require 'Model_Route.php';
require 'Model_Station.php';

class Model
{

    public function __construct()
    {

    }


    // Connection Stuff
    public function dbConnection(){
        $servername = 'localhost';
        $username = 'root';
        $password = '';
        $dbname = 'sbbplus';

        $conn = new mysqli($servername,$username,$password,$dbname);
        $conn->set_charset('utf8');
        return $conn;
    }


    // Worker
    public function addWorker($worker){
        $conn = $this->dbConnection();

        $firstname = $worker->firstname;
        $lastname = $worker->lastname;
        $position = $worker->position;

        $sql = "INSERT INTO Worker (firstname, lastname, position) VALUES ('".$firstname."','".$lastname."','".$position."')";
        $conn->query($sql);

        $conn->close();
    }

    public function deleteWorker($id){

    }

    public function updateWorker($worker){

    }

    public function getWorker(){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM Worker";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }

    public function getWorkerByFunction($function){

    }

    public function getWorkerPositions(){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM Position";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }


    // Train Material
    public function addMaterial($train){
        $conn = $this->dbConnection();

        $type = $train->type;
        $startDate = $train->startDate;
        $lastCheck = $train->lastCheck;
        $nextCheck = $train->nextCheck;
        $available = $train->available;
        $class = $train->class;
        $space = $train->space;

        $sql = "INSERT INTO Material(Type, StartDate, LastCheck, NextCheck, Class, Space, Available) VALUES ('".$type."','".$startDate."','".$lastCheck."','".$nextCheck."','".$class."','".$space."','".$available."')";
        $conn->query($sql);

        $conn->close();
    }

    public function deleteMaterial($id){

    }

    public function updateMaterial($material){
        $id = $material->id;
        $type = $material->type;
        $startDate = $material->startDate;
        $lastCheck = $material->lastCheck;
        $nextCheck = $material->nextCheck;
        $available = $material->available;
        if($type = 1) {
            $class = $material->class;
            $space = $material->space;
        }

        $conn = $this->dbConnection();
/*
        if($type=1){
            $sql="UPDATE Material SET 
            Type = ".$type.",
            StartDate = ".$startDate.",
            LastCheck = ".$lastCheck.",
            NextCheck = ".$nextCheck.",
            Class = ".$class.",
            Space = ".$space.",
            Available = ".$available."
            WHERE ID = ".$id.";";
        } else {
            $sql="UPDATE Material SET 
            Type = ".$type.",
            StartDate = ".$startDate.",
            LastCheck = ".$lastCheck.",
            NextCheck = ".$nextCheck.",
            Available = ".$available."
            WHERE ID = ".$id.";";
        }*/

        $sql="UPDATE Material SET
            Type = ".$type.",
            StartDate = ".$startDate.",
            LastCheck = ".$lastCheck.",
            NextCheck = ".$nextCheck.",
            Class = ".$class.",
            Space = ".$space.",
            Available = ".$available."
            WHERE ID = ".$id.";";

        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
            die();
        }

        $conn->close();
        return;
    }

    public function getMaterials(){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM Material";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }

    public function getMaterial($materialID){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM Material WHERE ID = ".$materialID.";";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }

    public function getMaterialsByType($type){

    }

    public function getMaterialTypes(){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM Type";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }

    public function getMaterialClasses(){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM Class";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }


    // Station
    public function addStation($station){

    }

    public function deleteStation($id){

    }

    public function updateStation($station){

    }

    public function getStations($route){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM ".$route.";";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }

    public function getStationById($id,$route){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM ".$route." WHERE ID = ".$id.";";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }



    // Routes
    public function updateStationFromRoute($route){

    }

    public function getRoutes(){
        $conn = $this->dbConnection();

        $sql = "SELECT * FROM Routes";
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }

    public function getRouteById($id){

    }


    // Timetable
    public function getWaitTimeTotal($route){
        $conn = $this->dbConnection();

        $sql = "SELECT SUM(Wait) AS W FROM ".$route.";";
        $result = $conn->query($sql);

        $conn->close();
        return $result;
    }

    public function  getTravelTimeTotal($route){
        $conn = $this->dbConnection();

        $sql = "SELECT SUM(TravelTime) AS T FROM ".$route.";";
        $result = $conn->query($sql);

        $conn->close();
        return $result;
    }


    // Other
    public function getPositionNameById($id){
        $conn = $this->dbConnection();

        $sql = "SELECT Position FROM Position WHERE ID =".$id;
        $results = $conn->query($sql);

        $conn->close();
        return $results;
    }



}