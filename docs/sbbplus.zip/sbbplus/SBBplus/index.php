<?php
include 'res/head.php';
include 'View/Nav.php';
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="functions.js"></script>
</head>
<body>
<div class="navbar">
    <?php echo getNavbar(); ?>
</div>
<br>
<br>
<br>
<a href=#><button>Manage Stations & Routes</button></a>
<a href="View/View_Timetable.php"><button>Zeitplan generieren</button></a>
<a href=#><button>Einsatzplan generieren</button></a>
<br>
<br>
<br>
<h2>TODO-List</h2>
<h3>Coding</h3>
<ul>
    <li>CRUD Material & Worker only create</li>
    <li>CRUD Stations</li>
    <li>CRUD Routes</li>
    <li><b>Generate Timetable</b></li>
    <li><b>Generate Workforce plan</b></li>
    <li>&nbsp;</li>
    <li>other/bonus stuff</li>
    <li>navbar & general workflow QOL changes</li>
    <li>manage material&workers</li>
    <li>design</li>
    <li>&nbsp;</li>
    <li>Order:</li>
    <li>Station & routes management</li>
    <li>- Data saving & reading</li>
    <li>timetable generation</li>
    <li>other generation</li>
    <li>all other stuff</li>
</ul>
<h3>Doku</h3>
<ul>
    <li>Review</li>
    <li>UML</li>
    <li>check timeplanning</li>
</ul>
<br>
<br>
<div>
    calc the timetable every train alone with dummy trains
        - generate 1 train, calc every station
        - generate 2nd train after 30 mins, calc every station etc

    calc the material and workers used
        route travel time(round up to 30 mins) / time interval

        that's basic calc
        should work
</div>
</body>
</html>
